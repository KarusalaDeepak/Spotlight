<?php
// This file was auto-generated from sdk-root/src/data/applicationcostprofiler/2020-09-10/paginators-1.json
return [ 'pagination' => [ 'ListReportDefinitions' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'reportDefinitions', ], ],];
