<?php
// This file was auto-generated from sdk-root/src/data/cognito-sync/2014-06-30/paginators-1.json
return [ 'pagination' => [],];
